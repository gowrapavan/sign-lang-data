# sign-lang-data > 2025-03-12 11:29pm
https://universe.roboflow.com/gowra/sign-lang-data-mp1dk

Provided by a Roboflow user
License: CC BY 4.0

